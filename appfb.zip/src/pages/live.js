import React from "react";

const Live = () => {
  return <h1>live page</h1>;
};
export default Live;
