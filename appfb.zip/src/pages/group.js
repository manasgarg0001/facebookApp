import React from "react";

const Group = () => {
  return <h1>Group page</h1>;
};
export default Group;
