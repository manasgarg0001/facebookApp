import React from "react";

const Messenger = () => {
  return <h1>Messenger page</h1>;
};
export default Messenger;
